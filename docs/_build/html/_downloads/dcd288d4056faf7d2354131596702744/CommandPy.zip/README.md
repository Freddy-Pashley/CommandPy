# CommandPy
A command prompt built with Python.

Copyright: Fred Pashley. All rights reserved.
FOR LICENSE, see "LICENSE" file.